package usearrays1;

import java.util.*;

class UseArrays1

// Demonstrates testing whether an integer is in an array of integers
{
 public static void main(String[] args) 
 {
  Scanner input = new Scanner(System.in);
  System.out.println("Enter some numbers (all on one line, separated by spaces):");
  String line = input.nextLine();
  String[] numbers = line.split(" +");
  int[] a = new int[numbers.length];
  for(int i=0; i<a.length; i++)
      a[i]=Integer.parseInt(numbers[i]);
  System.out.println("The numbers are stored in an array");
  System.out.print("Enter a number: ");
  int n = input.nextInt();
  if(isIn(a,n))
     System.out.println("The number "+n+" is in the array");
  else
     System.out.println("The number "+n+" is not in the array");
  
  int[] x = {8,11,7,12,5,10,5};
  int m = 9;
  int l = LessThanN(x, m);
  System.out.println(l);
  
  int[] y = {7,11,13,8,5,10,20};
  int n1= 12, n2=5;
  ConstruMul(y, n1, n2);
  DestruMul(y,n1,n2);
  
  int[] x2 = {19,9,30,47,5,10,20,36,21,11,13};
  int n3=25;
  int h= Closest(x2,n3);
  
  int[] x3 = {7,11,13,8,5,8,10,27,30,11,5};
  int n4 = 8;
  int n5 = 27;
  FromUpto(x3,n4,n5);
  
  int[] x4 = {17,11,20,34,5,10,8,19,55,11,13};
  int n6 = 12;
  remove(x4,n6);
  
  int[] x5 = {3,8,13,16,16,19,27,30};
  boolean isSort = FalseSort(x5);
  System.out.println(isSort);
  
  int[] x6 = {17,11,20,34,5,10,8,19,55,11,13};
  int[] x7 = {19,20,13,19,55,8};
  boolean isThere = inThere(x6,x7);
  System.out.println(isThere);
  
  int[] x8 = {7,11,40,8,5,10,8};
  int[] x9 = {35,10,13,40,7};
  int isThere2 = inThere2(x6,x7);
  System.out.println(isThere2);
 }

 public static boolean isIn(int[] a,int n)
 {
  for(int i=0; i<a.length; i++)
     {
      if(a[i]==n)
         return true;
     }
  return false;
 }
 
 public static int LessThanN (int[] a, int n)
 {
     int count = 0;
     int[] b = new int[a.length];
     for(int i = 0; i <= a.length-1; i++)
     {
         if(a[i] < n)
         {
             b[i] = a[i];
             count++;
         }     
     }
     return count;
 }
 
 public static void ConstruMul (int[] a, int n, int m)
 {
     int[] b = new int[a.length]; 
     for(int i = 0; i <= a.length-1; i++)
     {
         b[i] = a[i];
     }
     for(int i = 0; i <= b.length-1; i++)
     {
         if(b[i] < n)
         {
             b[i] = b[i] * m;
         }
     }
 }
 
 public static void DestruMul (int[] a, int n, int m)
 {
     for(int i = 0; i <= a.length-1; i++)
     {
         if(a[i] < n)
         {
             a[i] = a[i] * m;
         }
     }
 }
 
 public static int Closest(int[] a, int n)
 {
     int distance = Math.abs(a[0] - n);
     int m = 0;
     for(int i = 0; i <= a.length-1; i++)
     {
         int idistance = Math.abs(a[i] - n);
         if(idistance<distance)
         {
             m = i;
             distance = idistance;
         }
     }
     System.out.println("Possition " + m + " of value " +a[m] + " is closest to " + n);
     return m;
 }
 
 public static void FromUpto(int[] a, int n, int m)
 {
     int[] b = new int[a.length];
     for(int i = 0; i <= a.length-1; i++)
     {
         if(a[i]==n)
         {
             while(!(a[i]==m))
             {
                 b[i] = a[i];
                 System.out.print(b[i]+" ");
                 i++;
             }
             System.out.print("27");
             System.out.println(" ");
             return;
         }
     }
 }
 
 public static void remove(int[] a, int n)
 {
     int c =0;
     int[] b = new int[a.length];
     for(int i = 0; i <= a.length-1; i++)
     {
         if(a[i] > n)
         {
             b[c] = a[i];
             c++;
         }
     }
     for(int j = 0; j <= 5; j++)
     {
         System.out.print(b[j]+" ");
     }
     System.out.println(" ");
 }
 
 public static boolean FalseSort(int[] a)
 {
     for(int i = 0; i <= a.length-1; i++)
     {
         if(a[i] > a[i++])
         {
             return false;
         }
     }
     return true;
 }
 
 public static boolean inThere(int[] a, int[] b)
 {
     boolean n = false;
     breaker: for(int i = 0; i <= a.length-1; i++)
     {
         if(i==b.length)
             break breaker;
         for(int j = 0; j <= a.length-1; j++)
         {
            if(b[i]==a[j])
            {
                n=true;
                if(i==b.length-1)
                    return true;
            }
         }
     }
     return false;
 }
 
 public static int inThere2(int[] a, int[] b)
 {
     int n = 0;
     breaker: for(int i = 0; i <= a.length-1; i++)
     {
         if(i==b.length)
             break breaker;
         for(int j = 0; j <= a.length-1; j++)
         {
            if(b[i]==a[j])
            {
                n++;
                if(i==b.length-1)
                    return n/2;
            }
         }
     }
     return n;
 }
}
